#include "geneBank.h"

// =================================== PUBLIC FUNCTIONS =======================================================

GENE_BANK::GENE_BANK() 
{
    this->fileSize = 0;
    this->entryByte = sizeof(Sample);
}

GENE_BANK::~GENE_BANK() 
{
    cout << "Destructing ..." << endl;
}

void GENE_BANK::sort(Sample array[], int fileSize)
{
    // complete this
    // Implementation of Counting Sort (Highly efficient O(N) since we only have 5 species codes)
    int actualSize = fileSize + 1; 
    this->fileSize = actualSize;
    
    Sample* temp = new Sample[actualSize];
    int counts[5] = {0};
    
    // Count occurrences of each species code
    for (int i = 0; i < actualSize; ++i) {
        counts[array[i].speciesCode]++;
    }
    
    // Determine starting index for each species code
    int startIndex[5];
    startIndex[0] = 0;
    for (int i = 1; i < 5; ++i) {
        startIndex[i] = startIndex[i - 1] + counts[i - 1];
    }
    
    int currentIndex[5];
    for (int i = 0; i < 5; ++i) currentIndex[i] = startIndex[i];
    
    // Place into temp array to maintain record integrity
    for (int i = 0; i < actualSize; ++i) {
        int code = array[i].speciesCode;
        temp[currentIndex[code]++] = array[i];
    }
    
    // Copy the sorted records back to the original array
    for (int i = 0; i < actualSize; ++i) {
        array[i] = temp[i];
    }
    
    delete[] temp;
}

void GENE_BANK::indexSamples(Sample array[], int indexArray[]) 
{
    this->p_index(array, indexArray);
}

void GENE_BANK::displayResearcher(int speciesCode, int offset, char* filename) 
{
    bool checkSample;

    checkSample = searchSample(speciesCode, offset, filename);

    if(checkSample){
        p_displayResearcher(speciesCode, offset, filename);
    } else {
        cout << "Sample record doesn't exist! Can't display researcher name." << endl;
    }
}

bool GENE_BANK::searchSample(int speciesCode, int offset, char* filename) 
{
    // Note: The 'speciesCode' argument passed from main is actually the baseIndex (from indexArray)
    fstream file(filename, ios::in | ios::binary);
    if (!file.is_open()) return false;
    
    Sample temp;
    int pos = (speciesCode + offset) * this->entryByte;
    file.seekg(pos, ios::beg);
    
    if (file.read(reinterpret_cast<char*>(&temp), this->entryByte)) {
        file.close();
        if (temp.sampleID == -1) { // Assuming -1 marks a deleted record
            return false;
        }
        return true;
    }
    
    file.close();
    return false;
}


void GENE_BANK::updateResearcher(int speciesCode, int offset, char* newName, char* filename) 
{
    bool checkSample;

    checkSample = this->searchSample(speciesCode, offset, filename);

    if(checkSample){
        p_updateResearcher(speciesCode, offset, newName, filename);
    } else {
        cout << "Sample record to be updated doesn't exist!" << endl;
        p_updateResearcher(speciesCode, offset, newName, filename);
    }
}

void GENE_BANK::deleteSample(int speciesCode, int offset, char* filename)
{
    bool checkSample;

    checkSample = this->searchSample(speciesCode, offset, filename);

    if(checkSample){
        p_deleteSample(speciesCode, offset, filename);
    } else {
        cout << "Sample record to be deletesd doesn't exist!" << endl;
    }
}

void GENE_BANK::printSampleRange(int speciesCode, int startIndex, int endIndex, char* filename) 
{
    if(startIndex >= endIndex)
        throw MyException("ERROR: start index is larger than end index!");
    else
        this->p_printRange(speciesCode, startIndex, endIndex, filename);
}

// =================================== PRIVATE FUNCTIONS =======================================================

// your sorting algorithm here

void GENE_BANK::p_index(Sample array[], int indexArray[]) 
{
    // Initialize the array to -1
    for(int i = 0; i < 5; i++) {
        indexArray[i] = -1; 
    }
    
    // Find the first occurrence (starting index) of each species code
    for(int i = 0; i < this->fileSize; i++) {
        int code = array[i].speciesCode;
        if(indexArray[code] == -1) {
            indexArray[code] = i;
        }
    }

}

void GENE_BANK::p_displayResearcher(int speciesCode, int offset, char* filename) 
{
    /* These are the 5 unique species codes
        0 - H_SAP
        1 - M_MUS
        2 - D_MEL
        3 - E_COL
        4 - A_THA
    */
    fstream file(filename, ios::in | ios::binary);
    Sample temp;
    
    int pos = (speciesCode + offset) * this->entryByte;
    file.seekg(pos, ios::beg);
    file.read(reinterpret_cast<char*>(&temp), this->entryByte);
    
    cout << "Researcher Name: " << temp.researcher << endl;
    
    file.close();

}

void GENE_BANK::p_updateResearcher(int speciesCode, int offset, char* newName, char* filename) 
{
    fstream file(filename, ios::in | ios::out | ios::binary);
    Sample temp;
    
    int pos = (speciesCode + offset) * this->entryByte;
    file.seekg(pos, ios::beg);
    file.read(reinterpret_cast<char*>(&temp), this->entryByte);
    
    // Safely update the researcher name constraint to MAX_RESEARCHER_NAME
    strncpy(temp.researcher, newName, MAX_RESEARCHER_NAME - 1);
    temp.researcher[MAX_RESEARCHER_NAME - 1] = '\0';
    
    file.seekp(pos, ios::beg);
    file.write(reinterpret_cast<char*>(&temp), this->entryByte);
    
    file.close();

}

void GENE_BANK::p_deleteSample(int speciesCode, int offset, char* filename) 
{
    fstream file(filename, ios::in | ios::out | ios::binary);
    Sample temp;
    
    int pos = (speciesCode + offset) * this->entryByte;
    file.seekg(pos, ios::beg);
    file.read(reinterpret_cast<char*>(&temp), this->entryByte);
    
    // Logically delete by setting sampleID to -1
    temp.sampleID = -1; 
    
    file.seekp(pos, ios::beg);
    file.write(reinterpret_cast<char*>(&temp), this->entryByte);
    
    file.close();
}

void GENE_BANK::p_printRange(int speciesCode, int startIndex, int endIndex, char* filename) 
{
    fstream file(filename, ios::in | ios::binary);
    Sample temp;
    
    int pos = (speciesCode + startIndex) * this->entryByte;
    file.seekg(pos, ios::beg);
    
    for (int i = startIndex; i <= endIndex; i++) {
        file.read(reinterpret_cast<char*>(&temp), this->entryByte);
        
        if (file.eof()) break; // Safeguard if range exceeds file bounds
        
        if (temp.sampleID != -1) {
            cout << "Sample ID: " << temp.sampleID 
                 << " | Species Code: " << temp.speciesCode 
                 << " | Purity: " << temp.purityScore 
                 << " | Researcher: " << temp.researcher << endl;
        }
    }
    
    file.close();
}
